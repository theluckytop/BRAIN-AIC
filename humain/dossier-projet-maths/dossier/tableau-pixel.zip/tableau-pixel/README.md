# Tableau Pixel

Une interface de dessin guidé : un **carton de consignes** en haut, un **tableau blanc** en dessous, un **menu** logé dans l'encoche du tableau. Style pixel art minimaliste, rétro sans nostalgie appuyée : noir, blanc, un peu de gris, des carrés.

L'agencement vient directement du wireframe d'origine : un bandeau pleine largeur, puis un grand panneau dont le coin haut-gauche est découpé pour recevoir le bouton hamburger.

## Principes

1. **Tout est carré.** Aucun `border-radius` (`radius-none`). Une forme arrondie se construit en escalier de pixels.
2. **Le trait fait la forme.** Les panneaux existent par leur contour `ink` (`border-pixel`, 2px), pas par un fond coloré.
3. **Ombres dures.** `shadow-pixel` (4px) pour les panneaux, `shadow-pixel-sm` (2px) pour les boutons. Jamais de flou. À l'appui, le bouton se décale de 2px et perd son ombre.
4. **Grille de 4px.** Toutes les dimensions de l'interface sont des multiples de 4. Le tableau, lui, dessine en pixels de 2px : fin, mais toujours du pixel art.
5. **Noir et blanc.** Aucune couleur vive. Ce qui est actif ou principal s'**inverse** : fond `ink`, texte `surface` (l'étape en cours, l'outil choisi, le bouton « Suivant »). Le gris ne sert qu'au secondaire.
6. **Mouvement en marches.** Les animations utilisent `steps()` (curseur qui clignote), pas de fondus ni d'easing.

## Voix et contenu

- Consignes à l'impératif, tutoiement, une idée par étape : « Dessine une maison avec trois fenêtres. »
- Étiquettes et boutons en capitales, un ou deux mots : `SUIVANT`, `GOMME`, `EFFACER`.
- Numérotation sur deux chiffres : `ÉTAPE 01`, compteur `1 / 3`.
- Pas d'emoji. Les flèches ◀ ▶ sont les seuls glyphes décoratifs.

## Couleurs

| Rôle | Token | Usage |
| --- | --- | --- |
| Fond de page | `paper` | Derrière tout ; remplit l'encoche du tableau |
| Panneaux | `surface` | Carton, tableau, boutons |
| Encre | `ink` | Texte, contours, ombres, crayon par défaut |
| Encre douce | `ink-muted` | Compteurs, légendes |
| Grille | `grid` | Points du tableau, jamais du texte |
| Gris | `gray` | Crayon gris, ombre en thème sombre |

Deux thèmes : **Clair** (papier gris très clair, panneaux blancs, encre noire) et **Sombre** (noir, encre blanche) — l'un est l'inverse de l'autre. Le focus clavier est un contour `ink` en pointillés, décalé de 3px.

## Typographie

- **Silkscreen** (`--font-display`) — titres, étiquettes, boutons. Toujours en capitales pour `label`.
- **Pixelify Sans** (`--font-body`) — texte des consignes et texte courant ; lisible à 16px et plus.
- Polices Google Fonts, chargées par `https://fonts.googleapis.com/css2?family=Pixelify+Sans:wght@400;600&family=Silkscreen&display=swap`. Repli : `Courier New`, monospace.
- Désactiver le lissage (`-webkit-font-smoothing: none`) sur `.px-root` pour garder les bords nets.

## Espace, bordures, ombres

- Espacements : `space-1` 4 · `space-2` 8 · `space-3` 12 · `space-4` 16 · `space-6` 24 · `space-8` 32.
- Bordures : `border-hair` 1px (séparateurs), `border-pixel` 2px (panneaux, boutons), `border-bold` 3px (barres du menu).
- Le tableau dessine en pixels de 2px (`cell`) ; ses points de repère `grid` tombent tous les 16px, quelle que soit la taille du pixel.
- L'encoche du tableau mesure 72px : bouton menu 56px + `space-4`.

## Composants

- **ConsigneCard** — le carton de consignes, navigable.
- **Whiteboard** — le tableau blanc ; pixels de 2px, trois tailles de pointe, crayons noir et gris, gomme, effacer.
- **MenuButton** — le hamburger de l'encoche.
- **Button** — défaut, principal, fantôme, destructif.
- **AppShell** — l'écran complet du wireframe.

Composants en JavaScript natif, sans dépendance : `window.TableauPixel.AppShell({ steps })` renvoie l'écran prêt à insérer.

## Iconographie

Pas encore de jeu d'icônes : les outils sont nommés en toutes lettres, les crayons sont des pastilles carrées et les tailles de pointe des carrés pleins. Si des icônes arrivent, elles seront dessinées sur une grille de 16×16, un seul trait `ink` de 2px, sans anti-crénelage.

## À éviter

- Coins arrondis, dégradés, ombres floues.
- Toute couleur autre que le noir, le blanc et les gris des tokens.
- Du texte long en Silkscreen : elle est faite pour les étiquettes.
- Une action destructive sans libellé explicite (« Effacer »).
