# Whiteboard
L'espace de dessin : un canevas `surface` avec des points de repère `grid` tous les 16px ; chaque trait est tracé en pixels carrés de 2px alignés sur la grille (Bresenham), assez fins pour être précis, toujours nets.

- Barre d'outils en bas à droite, de gauche à droite : **taille de pointe** (1, 3 ou 6 pixels, soit 2, 6 ou 12px), **crayons** (`ink` noir, `gray` gris), **Gomme** (pointe deux fois plus large), **Effacer** (vide le tableau). L'outil actif s'inverse (fond `ink`).
- `notched: true` découpe l'encoche du coin haut-gauche (72px, fond `paper`) où se pose le MenuButton.
- Les couleurs sont lues dans les tokens au moment du dessin et repeintes quand le thème change : un dessin noir devient blanc en thème sombre.
- Le consommateur fournit : une hauteur (le composant remplit son conteneur), `cell` (taille d'un pixel en px, défaut 2 ; 1 pour la précision maximale, 8 pour un rendu très gros pixels), `sizes` (tailles de pointe en pixels), `colors` (noms de variables CSS), `tools: false` pour masquer la barre. `board.clear()`, `board.getPixels()`.
