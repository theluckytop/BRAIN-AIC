/* @ds-bundle: {"format":4,"namespace":"TableauPixel","components":[{"name":"Button"},{"name":"MenuButton"},{"name":"ConsigneCard"},{"name":"Whiteboard"},{"name":"AppShell"}]} */
(function () {
  "use strict";
  var doc = document;

  function el(tag, attrs, children) {
    var n = doc.createElement(tag);
    if (attrs) for (var k in attrs) {
      if (k === "class") n.className = attrs[k];
      else if (k === "text") n.textContent = attrs[k];
      else if (k === "style") n.setAttribute("style", attrs[k]);
      else if (k.slice(0, 2) === "on") n.addEventListener(k.slice(2), attrs[k]);
      else n.setAttribute(k, attrs[k]);
    }
    (children || []).forEach(function (c) { if (c) n.appendChild(typeof c === "string" ? doc.createTextNode(c) : c); });
    return n;
  }
  function cssVar(node, name) { return getComputedStyle(node).getPropertyValue(name).trim(); }

  /* Button({label, variant: "default"|"primary"|"ghost"|"danger", onClick}) -> HTMLButtonElement */
  function Button(o) {
    o = o || {};
    var v = o.variant && o.variant !== "default" ? " px-btn--" + o.variant : "";
    return el("button", { type: "button", class: "px-btn" + v, text: o.label || "", onclick: o.onClick || function () {} });
  }

  /* MenuButton({expanded, onToggle(expanded), label}) -> HTMLButtonElement */
  function MenuButton(o) {
    o = o || {};
    var b = el("button", { type: "button", class: "px-menu", "aria-label": o.label || "Menu", "aria-expanded": String(!!o.expanded) },
      [el("span"), el("span"), el("span")]);
    b.addEventListener("click", function () {
      var next = b.getAttribute("aria-expanded") !== "true";
      b.setAttribute("aria-expanded", String(next));
      if (o.onToggle) o.onToggle(next);
    });
    return b;
  }

  /* ConsigneCard({steps: [{title, text}], index, onChange(index)}) -> HTMLElement with .setIndex(i) */
  function ConsigneCard(o) {
    o = o || {};
    var steps = o.steps && o.steps.length ? o.steps : [{ title: "Consigne", text: "Dessine ce que tu veux." }];
    var i = Math.max(0, Math.min(o.index || 0, steps.length - 1));
    var num = el("b"), title = el("p", { class: "px-card__title" }), text = el("p", { class: "px-card__text", "aria-live": "polite" });
    var count = el("span", { class: "px-card__count" });
    var prev = Button({ label: "◀", onClick: function () { set(i - 1); } });
    var next = Button({ label: "▶", variant: "primary", onClick: function () { set(i + 1); } });
    prev.setAttribute("aria-label", "Consigne précédente"); next.setAttribute("aria-label", "Consigne suivante");
    var root = el("section", { class: "px-card", "aria-label": "Consignes" }, [
      el("div", { class: "px-card__tag" }, [el("span", null, ["Étape", num])]),
      el("div", { class: "px-card__body" }, [title, text]),
      steps.length > 1 ? el("div", { class: "px-card__nav" }, [prev, count, next]) : null
    ]);
    function pad(n) { return (n < 10 ? "0" : "") + n; }
    function set(n) {
      i = Math.max(0, Math.min(n, steps.length - 1));
      num.textContent = pad(i + 1);
      title.textContent = steps[i].title || "";
      text.textContent = steps[i].text || "";
      count.textContent = (i + 1) + " / " + steps.length;
      prev.disabled = i === 0; next.disabled = i === steps.length - 1;
      if (o.onChange) o.onChange(i);
    }
    set(i);
    root.setIndex = set;
    return root;
  }

  /* Whiteboard({cell: 2, sizes: [1,3,6], notched: false, colors: ["--ink","--gray"], tools: true}) -> HTMLElement with .clear() */
  function Whiteboard(o) {
    o = o || {};
    var cell = o.cell || 2;
    var sizes = o.sizes || [1, 3, 6];
    var colorVars = o.colors || ["--ink", "--gray"];
    var names = { "--ink": "noir", "--gray": "gris", "--ink-muted": "gris foncé" };
    var canvas = el("canvas", { class: "px-board__canvas", "aria-label": "Tableau blanc" });
    var root = el("div", { class: "px-board" + (o.notched ? " px-board--notched" : ""), style: "--px-cell:" + cell + "px" }, [canvas]);
    if (o.notched) root.appendChild(el("div", { class: "px-board__notch", "aria-hidden": "true" }));
    var ctx = canvas.getContext("2d");
    var state = { color: colorVars[0], erase: false, size: sizes[1] || sizes[0], down: false, last: null };
    var pixels = {}; /* "x,y" -> css var name */

    function redraw() {
      var r = root.getBoundingClientRect();
      canvas.width = Math.max(1, Math.round(r.width)); canvas.height = Math.max(1, Math.round(r.height));
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      for (var k in pixels) { var p = k.split(","); ctx.fillStyle = cssVar(root, pixels[k]); ctx.fillRect(p[0] * cell, p[1] * cell, cell, cell); }
    }
    function dab(x, y) { /* pointe carrée de state.size pixels (double pour la gomme) */
      var n = state.erase ? state.size * 2 : state.size, h = Math.floor((n - 1) / 2);
      for (var i = 0; i < n; i++) for (var j = 0; j < n; j++) plot(x - h + i, y - h + j);
    }
    function plot(x, y) {
      var k = x + "," + y;
      if (state.erase) { delete pixels[k]; ctx.clearRect(x * cell, y * cell, cell, cell); }
      else { pixels[k] = state.color; ctx.fillStyle = cssVar(root, state.color); ctx.fillRect(x * cell, y * cell, cell, cell); }
    }
    function line(a, b) { /* Bresenham : chaque trait reste sur la grille */
      var x0 = a[0], y0 = a[1], x1 = b[0], y1 = b[1];
      var dx = Math.abs(x1 - x0), sx = x0 < x1 ? 1 : -1, dy = -Math.abs(y1 - y0), sy = y0 < y1 ? 1 : -1, e = dx + dy;
      for (;;) {
        dab(x0, y0);
        if (x0 === x1 && y0 === y1) break;
        var e2 = 2 * e; if (e2 >= dy) { e += dy; x0 += sx; } if (e2 <= dx) { e += dx; y0 += sy; }
      }
    }
    function at(ev) { var r = canvas.getBoundingClientRect(); return [Math.floor((ev.clientX - r.left) / cell), Math.floor((ev.clientY - r.top) / cell)]; }
    canvas.addEventListener("pointerdown", function (ev) { state.down = true; canvas.setPointerCapture(ev.pointerId); state.last = at(ev); line(state.last, state.last); });
    canvas.addEventListener("pointermove", function (ev) { if (!state.down) return; var p = at(ev); line(state.last, p); state.last = p; });
    function up() { state.down = false; state.last = null; }
    canvas.addEventListener("pointerup", up); canvas.addEventListener("pointercancel", up);

    if (o.tools !== false) {
      var toolBtns = [];
      function select(btn) { toolBtns.forEach(function (b) { b.setAttribute("aria-pressed", String(b === btn)); }); }
      var swatches = colorVars.map(function (v) {
        var s = el("button", { type: "button", class: "px-swatch", style: "--sw:var(" + v + ")", "aria-label": "Crayon " + (names[v] || v), "aria-pressed": "false" });
        s.addEventListener("click", function () { state.color = v; state.erase = false; select(s); });
        toolBtns.push(s); return s;
      });
      var sizeBtns = sizes.map(function (n) {
        var d = Math.max(2, Math.min(16, n * cell));
        var s = el("button", { type: "button", class: "px-size", "aria-label": "Pointe " + n + " px", "aria-pressed": String(n === state.size) }, [el("i", { style: "--d:" + d + "px" })]);
        s.addEventListener("click", function () { state.size = n; sizeBtns.forEach(function (b) { b.setAttribute("aria-pressed", String(b === s)); }); });
        return s;
      });
      var eraser = Button({ label: "Gomme" });
      eraser.addEventListener("click", function () { state.erase = true; select(eraser); });
      toolBtns.push(eraser);
      var clear = Button({ label: "Effacer", variant: "danger", onClick: function () { root.clear(); } });
      select(swatches[0]);
      root.appendChild(el("div", { class: "px-board__tools", role: "toolbar", "aria-label": "Outils" },
        sizeBtns.concat([el("span", { class: "px-board__sep" })], swatches, [el("span", { class: "px-board__sep" }), eraser, clear])));
    }

    root.clear = function () { pixels = {}; ctx.clearRect(0, 0, canvas.width, canvas.height); };
    root.getPixels = function () { return JSON.parse(JSON.stringify(pixels)); };
    if (window.ResizeObserver) new ResizeObserver(redraw).observe(root);
    /* Re-peint quand le thème change (les couleurs viennent des tokens). */
    if (window.MutationObserver) new MutationObserver(redraw).observe(doc.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
    requestAnimationFrame(redraw);
    return root;
  }

  /* AppShell({steps, menu: ["Nouveau", ...], onMenu(item)}) -> HTMLElement : carton en haut, tableau encoché, menu dans l'encoche. */
  function AppShell(o) {
    o = o || {};
    var drawer = el("ul", { class: "px-shell__drawer", role: "menu" }, (o.menu || ["Nouveau tableau", "Consignes", "Exporter", "Aide"]).map(function (m) {
      return el("li", { role: "menuitem", tabindex: "-1", text: m, onclick: function () { menu.click(); if (o.onMenu) o.onMenu(m); } });
    }));
    var menu = MenuButton({ onToggle: function (open) { drawer.classList.toggle("is-open", open); } });
    var board = Whiteboard({ notched: true });
    var root = el("div", { class: "px-root px-shell" }, [
      ConsigneCard({ steps: o.steps }),
      el("div", { class: "px-shell__stage" }, [board, el("div", { class: "px-shell__menu" }, [menu]), drawer])
    ]);
    root.board = board;
    return root;
  }

  var ns = window.TableauPixel = window.TableauPixel || {};
  ns.Button = Button; ns.MenuButton = MenuButton; ns.ConsigneCard = ConsigneCard; ns.Whiteboard = Whiteboard; ns.AppShell = AppShell;
})();
