/** Tableau Pixel — composants en JavaScript natif (aucune dépendance). Chaque fonction renvoie un élément DOM à insérer. */
export interface ButtonProps { label: string; variant?: "default" | "primary" | "ghost" | "danger"; onClick?: (e: MouseEvent) => void; }
export declare function Button(props: ButtonProps): HTMLButtonElement;

export interface MenuButtonProps { expanded?: boolean; label?: string; onToggle?: (expanded: boolean) => void; }
export declare function MenuButton(props?: MenuButtonProps): HTMLButtonElement;

export interface ConsigneStep { title?: string; text: string; }
export interface ConsigneCardProps { steps: ConsigneStep[]; index?: number; onChange?: (index: number) => void; }
export declare function ConsigneCard(props: ConsigneCardProps): HTMLElement & { setIndex(i: number): void };

export interface WhiteboardProps {
  /** Taille d'un pixel de dessin, en px. Défaut 2. */
  cell?: number;
  /** Tailles de pointe proposées, en pixels de dessin. Défaut [1, 3, 6]. */
  sizes?: number[];
  /** Encoche en haut à gauche pour le MenuButton. */
  notched?: boolean;
  /** Variables CSS des crayons. Défaut ["--ink", "--gray"]. */
  colors?: string[];
  /** false masque la barre d'outils. */
  tools?: boolean;
}
export declare function Whiteboard(props?: WhiteboardProps): HTMLElement & { clear(): void; getPixels(): Record<string, string> };

export interface AppShellProps { steps?: ConsigneStep[]; menu?: string[]; onMenu?: (item: string) => void; }
export declare function AppShell(props?: AppShellProps): HTMLElement & { board: ReturnType<typeof Whiteboard> };
