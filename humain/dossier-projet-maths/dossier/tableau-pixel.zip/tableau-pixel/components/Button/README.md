# Button
Bouton carré à contour 2px et ombre pixel dure, qui « s'enfonce » de 2px à l'appui.

- `variant` : `default` (surface), `primary` (inversé : fond `ink`, texte `surface` — une seule action principale par zone), `ghost` (sans contour au repos, pour les actions secondaires dans une barre), `danger` (contour en pointillés au survol ; libellé explicite obligatoire).
- Libellé court, en capitales (style `label`, police display). Pas d'icône seule sans `aria-label`.
- Focus clavier : contour `ink` 2px en pointillés, décalé de 3px.
- Le consommateur fournit : `label`, `onClick`.
