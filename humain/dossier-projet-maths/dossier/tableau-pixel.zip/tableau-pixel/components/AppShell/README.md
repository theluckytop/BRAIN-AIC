# AppShell
L'écran complet tiré du wireframe : le carton de consignes en bandeau pleine largeur, puis le tableau blanc encoché qui occupe le reste, avec le MenuButton dans l'encoche et son menu déroulant.

- Marges de page `space-6`, écart carton/tableau `space-4`.
- Le consommateur fournit : une hauteur au conteneur, `steps` pour le carton, `menu` (libellés) et `onMenu(item)`. `shell.board` donne accès au tableau.
