# ConsigneCard
Le carton de consignes : une étiquette inversée (fond `ink`) « Étape NN », le texte de la consigne suivi d'un curseur clignotant, et une navigation ◀ n / N ▶.

- Occupe toute la largeur, au-dessus du tableau blanc (bandeau du wireframe).
- Texte de consigne en style `lead` : une phrase à l'impératif, 90 caractères maximum. Titre en `label` couleur `ink-muted`.
- Une seule consigne ? La navigation disparaît.
- Le curseur clignote en `steps(1)` (pas de fondu) et s'arrête si `prefers-reduced-motion`.
- Le consommateur fournit : `steps: [{title, text}]`, `index` de départ, `onChange(index)`. `card.setIndex(i)` change d'étape par code.
