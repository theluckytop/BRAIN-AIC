# MenuButton
Bouton « hamburger » de 56×56px : trois barres `ink` de 3px (`border-bold`), espacées de `space-1`.

- Se loge dans l'encoche en haut à gauche du tableau (voir AppShell), comme dans le wireframe.
- Ouvert (`aria-expanded="true"`) : fond `ink`, barres `surface` (inversé), bouton enfoncé.
- Le consommateur fournit : `onToggle(expanded)` et le menu qu'il ouvre ; `label` (défaut « Menu ») pour les lecteurs d'écran.
